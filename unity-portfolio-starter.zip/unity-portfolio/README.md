# Unity Developer Portfolio

A lightweight, responsive portfolio website for an aspiring Unity/C# developer.

## Before publishing

Replace these placeholders in `index.html`:
- `YOUR NAME` with your name or preferred professional display name
- `YOUR-USERNAME` with your GitHub username
- `YOUR-EMAIL@example.com` with a professional contact email

Make sure every claim about your experience and project progress is accurate.

## Publish with GitHub Pages

1. Create a public GitHub repository named `YOUR-USERNAME.github.io` (replace with your actual username).
2. Upload `index.html` to the root of the repository, commit it to the `main` branch.
3. Go to Settings → Pages → Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Wait a few minutes and open `https://YOUR-USERNAME.github.io`.

You can add gameplay screenshots, videos, a resume PDF, and more projects later.
